package com.example.potok;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView msgBox;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(R.id.button1);
        msgBox = (TextView) findViewById(R.id.msg);    }

    public void onClickBut1(View v){
        restartThread1();    }

    void restartThread1(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                work();
            }
        }).start();    }
    public void onClickBut2(View v){
        restartThread2();    }

    void restartThread2(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                work2();
            }
        }).start();    }
    public void onClickBut3(View v){
        restartThread3();    }

    void restartThread3(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                work3();
            }
        }).start();    }

    void showMessage(final String msg){
        msgBox.setText(msgBox.getText() + msg);
    }

    public void work(){
        for (int i=122; i>= 97; i--){
            try{
                final char k = (char)i;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showMessage(k + "");
                    }
                });
                Thread.sleep(1000);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }
    public void work2(){
        for(int i=0;i<100;i++) {
            try {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showMessage("!");
                    }
                });
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void work3(){
        for(int i=1;i<100;i++) {
            try {
                final int k = i;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showMessage(k*k+"");
                    }
                });
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
