package com.example.ded;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

public class Q1 extends AppCompatActivity {
    int answer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q1);
    }
    public void onRadioButtonClicked(View view) {
        // если переключатель отмечен
        boolean checked = ((RadioButton) view).isChecked();
        // Получаем нажатый переключатель
        switch(view.getId()) {
            case R.id.an1:
                if (checked){
                    answer = 1;
                }
                break;
            case R.id.an2:
                if (checked){
                    answer = 2;
                }
                break;
            case R.id.an3:
                if (checked){
                    answer = 3;
                }
                break;
            case R.id.an4:
                if (checked){
                    answer = 4;
                }
                break;
        }
    }
    public void confirm(View view) {
        Intent intent = new Intent(this, Q2.class);
        intent.putExtra("answer1",answer);
        startActivity(intent);
    }
}