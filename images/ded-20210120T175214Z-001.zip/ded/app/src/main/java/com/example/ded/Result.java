package com.example.ded;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Result extends AppCompatActivity {
    int answer1;
    int answer2;
    int answer3;
    int result = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        TextView finalResult = (TextView) findViewById(R.id.result);
        Bundle arguments = getIntent().getExtras();
        if (arguments!=null){
            answer1 = (int) arguments.get("answer1");
            answer2 = (int) arguments.get("answer2");
            answer3 = (int) arguments.get("answer3");
        }
        if (answer1 == 1){
            result++;
        }
        if (answer2 == 3){
            result++;
        }
        if (answer3 == 2){
            result++;
        }
        finalResult.setText(result + " Points");
    }
}