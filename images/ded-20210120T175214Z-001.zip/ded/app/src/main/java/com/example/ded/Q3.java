package com.example.ded;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

public class Q3 extends AppCompatActivity {

    int answer1;
    int answer2;
    int answer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q3);
        Bundle arguments = getIntent().getExtras();
        if (arguments!=null){
            answer1 = (int) arguments.get("answer1");
            answer2 = (int) arguments.get("answer2");
        }
    }
    public void onRadioButtonClicked(View view) {
        // если переключатель отмечен
        boolean checked = ((RadioButton) view).isChecked();
        // Получаем нажатый переключатель
        switch(view.getId()) {
            case R.id.an1:
                if (checked){
                    answer = 1;
                }
                break;
            case R.id.an2:
                if (checked){
                    answer = 2;
                }
                break;
            case R.id.an3:
                if (checked){
                    answer = 3;
                }
                break;
            case R.id.an4:
                if (checked){
                    answer = 4;
                }
                break;
        }

    }
    public void confirm(View view) {
        Intent intent = new Intent(this, Result.class);
        intent.putExtra("answer1",answer1);
        intent.putExtra("answer2",answer2);
        intent.putExtra("answer3",answer);
        startActivity(intent);
    }
}